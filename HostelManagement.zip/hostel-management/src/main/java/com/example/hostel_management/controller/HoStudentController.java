package com.example.hostel_management.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.hostel_management.model.HoStudent;
import com.example.hostel_management.repository.HoStudentRepository;

@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "http://localhost:4200")
public class HoStudentController {

    @Autowired
    private HoStudentRepository studentRepository;

    // Get all students
    @GetMapping
    public List<HoStudent> getAllStudents() {
        return studentRepository.findAll();
    }

    // Add a new student
    @PostMapping
    public ResponseEntity<String> addStudent(@RequestBody HoStudent student) {
        studentRepository.save(student);
        return ResponseEntity.ok("Student added successfully");
    }

    // Delete student by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable Long id) {
        if (studentRepository.existsById(id)) {
            studentRepository.deleteById(id);
            return ResponseEntity.ok("Deleted successfully");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Update student by ID
    @PutMapping("/{id}")
    public ResponseEntity<String> updateStudent(@PathVariable Long id, @RequestBody HoStudent updatedStudent) {
        Optional<HoStudent> optionalStudent = studentRepository.findById(id);
        if (optionalStudent.isPresent()) {
            HoStudent student = optionalStudent.get();
            student.setMessId(updatedStudent.getMessId());
            student.setName(updatedStudent.getName());
            student.setRoomNo(updatedStudent.getRoomNo());
            studentRepository.save(student);
            return ResponseEntity.ok("Edited successfully");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Get student by ID
    @GetMapping("/{id}")
    public ResponseEntity<HoStudent> getStudentById(@PathVariable Long id) {
        Optional<HoStudent> student = studentRepository.findById(id);
        return student.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }
}
