package com.example.hostel_management.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.hostel_management.model.HoStudent;


@Repository
public interface HoStudentRepository extends JpaRepository<HoStudent , Long> {

}
