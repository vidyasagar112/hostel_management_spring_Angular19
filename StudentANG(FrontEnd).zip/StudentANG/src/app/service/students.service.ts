import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Students } from '../models/students';

@Injectable({
  providedIn: 'root'
})
export class StudentsService {

  private baseUrl = 'http://localhost:8080/students'; // Unified REST base

  constructor(private http: HttpClient) {}

  // Get all students
  getAllStudents(): Observable<Students[]> {
    return this.http.get<Students[]>(this.baseUrl);
  }

  // Get a single student by ID
  getStudentById(id: number): Observable<Students> {
    return this.http.get<Students>(`${this.baseUrl}/${id}`);
  }

  // Update a student
  updateStudent(id: number, student: Students): Observable<string> {
    return this.http.put<string>(`${this.baseUrl}/${id}`, student, {
      responseType: 'text' as 'json'
    });
  }

  // Delete a student
  deleteStudent(id: number): Observable<string> {
    return this.http.delete<string>(`${this.baseUrl}/${id}`, {
      responseType: 'text' as 'json'
    });
  }

  // Create a new student
  createStudent(student: Students): Observable<string> {
    return this.http.post<string>(this.baseUrl, student, {
      responseType: 'text' as 'json'
    });
  }
}
