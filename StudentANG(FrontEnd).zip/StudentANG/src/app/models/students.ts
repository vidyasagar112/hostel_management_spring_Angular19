export interface Students {
    id:number;
    name: string;
    roomNo: string;
    messId: number;
}
